<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inicio - CBTis 145</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto+Condensed:300,300i,400,400i,700i" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.3.1/css/all.css" integrity="sha384-mzrmE5qonljUremFsqc01SB46JvROS7bZs3IO2EmfFsd15uHvIt+Y8vEf7N7fWAU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    <link type="text/css" rel="stylesheet" href="style.css"/>
</head>
<body>
    <header class="header">
        <nav class="navigation">
        <img src="assets/img/logo.png" alt="logo">
        <section class="logo"></section>
        <section class="navigation__icon">
            <span class="topBar"></span>
            <span class="middleBar"></span>
            <span class="bottomBar"></span>
        </section>

        <ul class="navigation__ul">
            <li><a href="">INICIO</a></li>
            <li><a href="">ALUMNOS</a></li>
            <li><a href="">GRUPOS</a></li>
            <li><a href="">ENCUESTAS</a></li>
            <li><a href="">CERRAR SESIÓN</a></li>
        </ul>

        <section class="navigation__social">
            <ul class="navigation__social-ul">
                <li>
                    <a href="" class="social-icon"></a>
                </li>
                <li>
                    <a href="" class="social-icon"></a>
                </li>
                <li>
                    <a href="" class="social-icon"></a>
                </li>
                <li>
                    <a href="" class="social-icon"></a>
                </li>
        </ul>
        </section>
        </nav>
</header>
<div class="wrapper">
  <div class="search-box">
     <input type="text" placeholder="Buscar" class="input">
     <div class="btn">
       <i class="fa fa-search" aria-hidden="true"></i>
     </div>
  </div>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script>
    
        
   
     $(function() {
   $(".navigation__icon").click(function() {
     $(".navigation").toggleClass('navigation-open');
   });
 });
  
    
        
   
    
    </script>
<script type="text/javascript" src="assets/js/button.js"></script>
</body>
</html>