<?php
session_start();
header("Content-Type: text/plain; charset=utf-8");
require_once('utils.php');
    
    if (isset($_POST["idusuario"]) && isset($_POST["idusuario"]) != "" 
    && isset($_POST["correo"]) && isset($_POST["correo"]) != "" )
    {
        $idusuario = test_input($_POST['idusuario']);
        $correo = test_input($_POST['correo']);
        if(strlen($idusuario) > 0 && strlen($correo) > 0)
        {
            $password = recover_pass($idusuario, $correo);
            $_SESSION['idusuario'] = $idusuario;
            $login = retrieve_login($idusuario, $password);
            if ($login != 0){
                $_SESSION = $login;
                $_SESSION['permisos'] = select_permissions($_SESSION['idrol']);
                $_SESSION['errorMessage'] = "Por medidas de seguridad, te sugerimos cambiar tu contraseña";
                header('Location:../views/perfil.php');
                exit();
            }else{
                $_SESSION['errorMessage'] = "Este no es el correo asociado a esta cuenta";
                header('Location:../views/recuperarContrasena.php');
            }
        }
    }

    function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }
?>