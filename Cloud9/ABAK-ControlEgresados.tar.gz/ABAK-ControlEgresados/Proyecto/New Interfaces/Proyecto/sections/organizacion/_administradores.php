    <div id = "administradores">
        
    </div>
    <script type="text/javascript" src=""></script>
    
    <?php $js .= '<script type="text/javascript" src="'.$httpProtocol.$host.$url.'js/verAdministradores.js"></script>';?>