    <footer class="page-footer">
      <div class="footer-copyright">
        <div class="container">
          <div class="row">
              © 2019  Control de Egresados - Creado por <a href="mailto:a01703171@itesm.mx;a01703446@itesm.mx;a01703442@itesm.mx;a01703424@itesm.mx" class="white-text">A'BAK TEAM</a>
              <div class="right">
              <a href="mailto:a01703171@itesm.mx;a01703446@itesm.mx;a01703442@itesm.mx;a01703424@itesm.mx" class="white-text">Contáctanos</a>  
              </div>
              <div class="col right">
                 | 
              </div>
              <div class="right">
                <a href="avisoPrivacidad.php" class="white-text">Aviso de privacidad</a>
              </div>
        </div>
      </div>
    </footer>
    <?php echo $js;?>
  </body>
</html>