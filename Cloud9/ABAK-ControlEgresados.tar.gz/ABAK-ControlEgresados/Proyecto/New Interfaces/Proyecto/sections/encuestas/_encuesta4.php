<div class="col s12 m6 l4">
  
    <p>
      <h6>Porcentaje de encuestas contestadas:</h6>
      <h6 class="center-align" id="porcentaje4">0%</h6>
    </p>
    <div class="card">
      <div class="card-image waves-effect waves-block waves-light">
        <img src="<?php echo $httpProtocol.$host.$url.'img/encuestas/encuestas.jpg'?>" alt="alumnos-img">
      </div>
      <div class="card-content blue darken-4 white-text">
        <span class="card-title">4to Semestre</span>
      </div>
      <div class="card-action blue darken-4">
        <div class="switch center-align">
          <label class="white-text">
            Inactiva
            <input type="checkbox" id="Encuesta4oSemestre" data-survey="Encuesta4oSemestre">
            <span class="lever"></span>
            Activa
          </label>
        </div>
      </div>
    </div>
</div>