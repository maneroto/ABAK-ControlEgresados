$(document).ready(function()
{
   $.ajax(
       {
          type: "GET",
          url: '../php/verDirectores.php',
          success: function(data)
          {
              $('#directores').html(data);
          }
       });
      
});