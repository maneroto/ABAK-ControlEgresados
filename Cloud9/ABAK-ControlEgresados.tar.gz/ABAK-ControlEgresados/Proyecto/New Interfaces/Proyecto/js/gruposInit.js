$(document).ready(function()
{
   $('#viewsGrupos').addClass('active');
   
   $.ajax({
      type: "GET",
      url: '../php/selectGeneracion.php',
      success: function(data)
      {
          $('#generacion').append(data);
          $('#generacion').formSelect();
      }
    });
    
    $("#nombre").on('change',function(){
        var nombre = $('#nombre').val();
        if(nombre == "")
            $("#span_nombre").text("Campo obligatorio");
        else
            $("#span_nombre").text("");
    });
    
    $("#especialidad").on('change',function(){
        var especialidad = $('#especialidad').val();
        if(especialidad == "")
            $("#span_especialidad").text("Campo obligatorio");
        else
            $("#span_especialidad").text("");
    });
    
    $("#turno").on('change',function(){
        var turno = $('#turno').val();
        if(turno == "")
            $("#span_turno").text("Campo obligatorio");
        else
            $("#span_turno").text("");
    });
    
    $("#semestre").on('change',function(){
        var semestre = $('#semestre').val();
        if(semestre == "")
            $("#span_semestre").text("Campo obligatorio");
        else
            $("#span_semestre").text("");
    });
    
    $("#generacion").on('change',function(){
        var generacion = $('#generacion').val();
        if(generacion == "")
            $("#span_generacion").text("Campo obligatorio");
        else
            $("#span_generacion").text("");
    });
    
});