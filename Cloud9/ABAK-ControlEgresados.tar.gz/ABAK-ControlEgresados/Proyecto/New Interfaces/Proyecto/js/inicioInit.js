$(document).ready(function()
{
   $('#viewsInicio').addClass('active');
      
});