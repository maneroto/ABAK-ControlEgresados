
$(document).ready(function(){

    $('#viewsOrganizacion').addClass('active');  

  
});