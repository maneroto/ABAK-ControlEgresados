$(document).ready(function()
{
   $('#viewsAPerfil').addClass('active');
      
});