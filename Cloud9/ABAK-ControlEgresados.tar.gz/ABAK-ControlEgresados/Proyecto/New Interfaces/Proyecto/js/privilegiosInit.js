$(document).ready(function()
{
   $.ajax(
       {
          type: "GET",
          url: '../php/obtenerPrivilegios.php',
          success: function(data)
          {
              $('#privilegios').append(data);
              $('#privilegios').formSelect();
          }
       });
       
     $('#cambiarPrivilegios').submit(function(e) {
        e.preventDefault();
        $.ajax({
            type: "POST",
            url: '../php/cambiarPrivilegios.php',
            data: $(this).serialize(),
            success: function(data){
                alert(data);
            }
        });
    });
      
});