
$(window).on('load',function() {
    $('#preloader').fadeOut('slow');
    M.AutoInit();
});


