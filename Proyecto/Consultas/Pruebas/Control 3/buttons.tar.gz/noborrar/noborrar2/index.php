<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Consultas - CBTis 145</title>
	<link rel="stylesheet" href="css/bootstrap.min.css">
	<link rel="stylesheet" href="css/dataTables.bootstrap.min.css">
	<link rel="stylesheet" href="css/estilos.css">
	<!-- Buttons DataTables -->
	<link rel="stylesheet" href="css/buttons.bootstrap.min.css">
	<link rel="stylesheet" href="css/font-awesome.min.css">

</head>
<body>
	<br /><br />  
           <div class="container">  
                <h3 align="center">Alumnos</h3>  
                <br />  
                <div class="table-responsive">  
                     <table id="student_data" class="table table-striped table-bordered">  
                          <thead>  
                               <tr>  
                                    <td>ID</td>  
                                    <td>Nombre</td>  
                                    <td>Apellido Paterno</td>  
                                    <td>Apellido Materno</td>  
                                    <td>Sexo</td>
                                    <td>Email</td>
                                    <td>Teléfono</td>
                                    <td>Especialidad</td> 
                                    <td>Contacto</td>
                               </tr>  
                          </thead>
                     </table>  
                </div>  
           </div>
	<script src="js/jquery-1.12.3.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/jquery.dataTables.min.js"></script>
	<script src="js/dataTables.bootstrap.js"></script>
	<!--botones DataTables-->
	<script src="js/dataTables.buttons.min.js"></script>
	<script src="js/buttons.bootstrap.min.js"></script>
	<!--Libreria para exportar Excel-->
	<script src="js/jszip.min.js"></script>
	<!--Librerias para exportar PDF-->
	<script src="js/pdfmake.min.js"></script>
	<script src="js/vfs_fonts.js"></script>
	<!--Librerias para botones de exportación-->
	<script src="js/buttons.html5.min.js"></script>
	<script src="js/buttons.print.js"></script>



	<script>		
		$(document).on("ready", function(){
			listar();
		});
        
        var listar = function(){
            var spanishlang = {
              "sProcessing":     "Por favor espere...",
              "sLengthMenu":     "Mostrar _MENU_ registros",
              "sZeroRecords":    "No se encontraron resultados",
              "sEmptyTable":     "Ningún dato disponible en esta tabla",
              "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
              "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
              "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
              "sInfoPostFix":    "",
              "sSearch":         "Buscar:",
              "sUrl":            "",
              "sInfoThousands":  ",",
              "sLoadingRecords": "Cargando...",
              "oPaginate": {
                  "sFirst":    "Primero",
                  "sLast":     "Último",
                  "sNext":     "Siguiente",
                  "sPrevious": "Anterior"
              },
              "oAria": {
                  "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                  "sSortDescending": ": Activar para ordenar la columna de manera descendente"
              }
            }
            var table = $("#student_data").DataTable({
                dom: 'lfrtipB',
                "buttons":[ 
                    { 
                    text: '<i class="fa fa-user-plus"></i>',
                    titleAttr: 'Agregar',
                    className: 'btn btn-success',
                    action: function(){ 
                        agregar_nuevo_usuario();
                        
                        } 
                    },
                    { 
                    extend: 'excelHtml5',
                    text: '<i class="fa fa-file-excel-o"></i>',
                    titleAttr: 'Excel'
                    },
                    {
                    extend: 'csvHtml5',
                    text: '<i class="fa fa-file-text-o"></i>',
                    titleAttr: 'CSV'
                    
                    },
                    {
                    extend: 'print',
                    text: 'Imprimir',
                    exportOptions: {
                        modifier: {
                            page: 'current'
                            }
                        },
                    action: function(){ window.print() }
                    }
                ],
                // buttons: [
                //     'copy', 'csv', 'excel', 'pdf', 'print'
                // ],
                
        //         buttons: [
        //     {
        //         extend: 'csv', text: 'CSV',
        //         customize: function (csv) {
        //             var csvRows = csv.split('\n');
        //             //csvRows[0] = csvRows[0].replace('"No. Serie"', '"Prro"')
        //             //csvRows[2] = csvRows[2].replace((csvRows[2].toString()), '"Prro"')
        //             return csvRows.join('\n');
        //         }
        //     },
        //     {
        //         extend: 'excel', text: 'Excel'
        //     },
        //     {
        //         extend: 'pdf', text: 'PDF'
        //     },
        //     {
        //         extend: 'print', text: 'Imprimir'
        //     }
        //   ],
        //      "lengthMenu": [ [10, 25, 50, 1], [10, 25, 50, "All"] ],
        //      "columnDefs":[
        //       {
        //       "targets":[2],
        //       "orderable":false,
        //       },
        // ],
                
                "language": spanishlang,//Cambia el idioma de la tabla a spanish.
                "processing":true,
                //"serverSide":true,
                "ajax":{
                    "method":"POST",
                    "url":"list.php"
                },
                "columns":[
                    {"data":"idusuario"},
                    {"data":"nombre"},
                    {"data":"apaterno"},
                    {"data":"amaterno"},
                    {"data":"sexo"},
                    {
                    "data":"email"
                    },
                    {"render": function ( data, type, full, meta ) {
                          return '<a class="btn btn-success" href="https://api.whatsapp.com/send?phone=15551234567" target="_blank"><i class="fa fa-whatsapp" aria-hidden="true"></i></a>';
                        }},
                    {"data":"especialidad"},
                    {
                    "render": function ( data, type, full, meta ) {
                          return '<a class="btn btn-success" href="mailto:' + full.email + '?"><i class="fa fa-paper-plane" aria-hidden="true"></i></a>';
                        }
                    }
                ]//Se obtienen los datos de cada una de las columnas desde la base de datos.
            });
        }
		
		
		

	</script>
</body>
</html>
