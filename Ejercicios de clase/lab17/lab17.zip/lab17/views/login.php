<!DOCTYPE html>
<html>
    <head>
        <title>
            Casino DAW-BD
        </title>
        <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
        <meta charset = "utf-8">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/1.0.0/css/materialize.min.css">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link rel="stylesheet" href="../css/login.css">
    </head>
    <body>
    	<div class="box">
    		<h2>Login</h2>
    		<form action="panelcontrol.php">
    			<div class="inputBox">
    				<input type="text" name="" required="">
    				<label for="">Username</label>
    			</div>
    			<div class="inputBox">
    				<input type="password" name="" required="">
    				<label for="">Password</label>
    			</div>
    			<input type="submit" name="" value="Submit">
    		</form>
    	</div>
    </body>
</html>
