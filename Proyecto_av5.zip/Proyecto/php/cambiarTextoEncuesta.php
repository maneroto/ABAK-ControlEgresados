<?php
    require_once("utils.php");
    
    if(surveyIsActive()) {
      echo "Encuesta activa";  
    } else {
      echo "Encuesta inactiva";
    }
?>