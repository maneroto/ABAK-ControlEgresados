<?php
    session_start();
    $idusuario = $_SESSION['idusuario'];
    
    require_once("utils.php");
    
    if (isset($_POST["newPass"]) && isset($_POST["newPass"]) != "" &&
    isset($_POST["newPassCon"]) && isset($_POST["newPassCon"]) != "" )
    {
        $newPass = test_input($_POST['newPass']);
        $newPassCon = test_input($_POST['newPassCon']);

        if(strlen($idusuario) > 0 && strlen($newPass) > 0 && strlen($newPassCon) > 0)
        {
            if($newPass != $newPassCon) echo "Las contraseñas no coinciden";
            
            if (modify_pass($idusuario, $newPassCon))
            {
                echo "Éxito al modificar contraseña";
            }
            else
            {
                echo "Falla al modificar contraseña";
            }
        }
    }

    function test_input($data) {
      $data = trim($data);
      $data = stripslashes($data);
      $data = htmlspecialchars($data);
      return $data;
    }    
    
?>