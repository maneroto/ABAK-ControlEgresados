<?php

    require_once("utils.php");
        
    if (surveyIsActive) {
        closeSurvey();
    } else {
        openSurvey();
    }
    
?>