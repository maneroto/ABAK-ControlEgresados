                        <div class="col s12 m6 l3">
                            <div class="card">
                                <a href="<?php echo $httpProtocol.$host.$url.'views/registros.php'?>">
                                    <div class="card-image waves-effect waves-block waves-light">
                                            <img src="<?php echo $httpProtocol.$host.$url.'img/inicio/reportes.jpg'?>">
                                    </div>
                                    <div class="card-content  blue darken-4 white-text center-align">
                                        <p class="card-stats-title">
                                            <i class="small material-icons">group_add</i>
                                        </p>
                                        <h4 class="card-stats-number">
                                            Registros
                                        </h4>
                                    </div>
                                </a>
                            </div>
                        </div>