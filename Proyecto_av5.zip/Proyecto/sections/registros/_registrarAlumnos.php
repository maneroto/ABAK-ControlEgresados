  <div id="add_persons">
    <form id="registrarAlumnos" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" enctype="multipart/form-data">
      <div class="row">
        <div class="input-field col s12">
          <select id="grupos" name="grupos" required>
            <option value="" disabled selected>Grupo</option>
          </select>
          <label>Grupo</label>
          <span id="span_grupos" class="error">Campo obligatorio</span>
        </div>
      </div>
      <div class="row">
        <div class="file-field input-field">
          <div class="btn">
            <span>Subir</span>
            <input type="file" name="file" accept=".csv" required>
          </div>
          <div class="file-path-wrapper">
            <input class="file-path validate" type="text" placeholder="Sube aquí tu .csv">
          </div>
        </div>
      </div>
      <div class="row">
        <button class="waves-effect waves-light btn" type="submit" name="action"><i class="material-icons left">cloud_upload</i>Registrar alumnos</button>
      </div>
    </form>
  </div>