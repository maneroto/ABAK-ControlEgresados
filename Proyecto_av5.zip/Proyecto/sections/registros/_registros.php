<section class="container">
  <p class="caption">Panel de registros</p>
  <hr>
  <br>
  <div class="row">
    <div class="col s12">
      <ul class="tabs">
        <?php
          if(in_array(array("REGISTRAR GRUPO"),$_SESSION['permisos']))
            echo '
            <li class="tab col s4">
              <a href="#add_group"><i class="material-icons prefix">group-add</i>Registrar grupo </a>
            </li>';
        ?>
        <?php
          if(in_array(array("REGISTRAR ALUMNO"),$_SESSION['permisos']))
              echo '
              <li class="tab col s4">
                <a href="#add_persons"><i class="material-icons prefix">group-add</i>Registrar alumnos</a>
              </li>
              <li class="tab col s4">
                <a href="#add_person"><i class="material-icons prefix">person-add</i>Registrar alumno</a>
              </li>';
        ?>
      </ul>
    </div>
  </div>
  <?php
    if(in_array(array("REGISTRAR GRUPO"),$_SESSION['permisos']))
      include('_registrarGrupo.php');
  ?>
  <?php
    if(in_array(array("REGISTRAR ALUMNO"),$_SESSION['permisos']))
    {
      include('_registrarAlumnos.php');
      include('_registrarAlumno.php');
    }
  ?>
</section>