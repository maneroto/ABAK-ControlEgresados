<div id="mainEncuestas">
  <section id="content">
    <div class="container">
      <div class="section">
        <p class="caption">Panel de encuestas</p>
        <hr>
        
        <div id="card-stats">
          <div class="row">
            <div class="col s12 m6 l4">
              <form id="encuesta4" method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
                <div class="card">
                  <div class="card-image waves-effect waves-block waves-light">
                    <img src="<?php echo $httpProtocol.$host.$url.'img/encuestas/encuestas.jpg'?>" alt="alumnos-img">
                  </div>
                  <div class="card-content blue darken-4 white-text">
                    <span class="card-title">4to Semestre</span>
                    <p id="texto_estatus_cuarto"></p>
                  </div>
                  <div class="card-action blue darken-4">
                    <a href="#" class="white-text activator" id="boton_activar_4">Activar</a>
                    <a href="#desactivar_4" class="white-text modal-trigger" id="boton_desactivar_4">Desactivar</a></a>
                  </div>
                      <!--Modal desactivar-->
                      <div id="desactivar_4" class="modal">
                        <div class="modal-content">
                          <p>¿Estas seguro de que deseas desactivar la encuesta?</p>
                        </div>
                        <div class="modal-footer">
                          <button class="modal-close waves-effect waves-green btn-flat" type="submit" value="desactivar" id="desactivar_4">Si</button>
                          <a href="#" class="modal-close waves-effect waves-red btn-flat">No</a>
                        </div>
                      </div>
                      <!--Modal activar-->
                      <div class="card-reveal">
                        <div class="card-reveal-content">
                          <span class="card-title grey-text text-darken-4">4to Semestre<i class="material-icons right">close</i></span>
                          <p>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">today</i>
                              <input id="fecha_apertura_4" name="fecha_apertura_4" type="text" class="datepicker">
                              <label for="fecha_apertura_4">Fecha de apertura</label>
                            </div>
                            <div class="input-field col s12">
                              <i class="material-icons prefix">today</i>
                              <input id="fecha_cierre_4" name="fecha_cierre_4" type="text" class="datepicker">
                              <label for="fecha_cierre_4">Fecha de cierre</label>
                            </div>
                            <button class="btn blue waves-effect waves-light" type="submit" value="activar_4">Listo</button>
                          </p>
                        </div>
                      </div>
                </div>
              </form>
            </div>
            
            <div class="col s12 m6 l4">
              <div class="card">
                <div class="card-image waves-effect waves-block waves-light">
                  <img class="activator" src="<?php echo $httpProtocol.$host.$url.'img/encuestas/encuestas.jpg'?>" alt="grupos-img">
                </div>
                <div class="card-content  blue darken-4 white-text">
                  <span class="card-title activator">6to Semestre</span>
                </div>
                <div class="card-reveal">
                  <div class="card-reveal-content">
                    <span class="card-title grey-text text-darken-4">6to Semestre<i class="material-icons right">close</i></span>
                    <p>
                      <div class="input-field col s12">
                        <i class="material-icons prefix">today</i>
                        <input id="fecha_apertura_6" name="fecha_apertura_6" type="text" class="datepicker">
                        <label for="fecha_apertura_6">Fecha de apertura</label>
                      </div>
                      <div class="input-field col s12">
                        <i class="material-icons prefix">today</i>
                        <input id="fecha_cierre_6" name="fecha_cierre_6" type="text" class="datepicker">
                        <label for="fecha_cierre_6">Fecha de cierre</label>
                      </div>
                      <div class="input-field col s10">
                        <div class="switch">
                          <label>
                            Cerrada
                            <input id="activarSexto" type="checkbox">
                            <span class="lever"></span>
                            Abierta
                          </label>
                        </div>
                      </div>
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="col s12 m6 l4">
              <div class="card">
                <div class="card-image waves-effect waves-block waves-light">
                  <img class="activator" src="<?php echo $httpProtocol.$host.$url.'img/encuestas/encuestas.jpg'?>" alt="grupos-img">
                </div>
                <div class="card-content  blue darken-4 white-text">
                  <span class="card-title activator">Egresados</span>
                </div>
                <div class="card-reveal">
                  <div class="card-reveal-content">
                    <span class="card-title grey-text text-darken-4">Egresados<i class="material-icons right">close</i></span>
                    <p>
                      <div class="input-field col s12">
                        <i class="material-icons prefix">today</i>
                        <input id="fecha_apertura_egresados" name="fecha_apertura_egresados" type="text" class="datepicker">
                        <label for="fecha_apertura_egresados">Fecha de apertura</label>
                      </div>
                      <div class="input-field col s12">
                        <i class="material-icons prefix">today</i>
                        <input id="fecha_cierre_egresados" name="fecha_cierre_egresados" type="text" class="datepicker">
                        <label for="fecha_cierre_egresados">Fecha de cierre</label>
                      </div>
                      <div class="input-field col s10">
                        <div class="switch">
                          <label>
                            Cerrada
                            <input id="activarEgresados" type="checkbox">
                            <span class="lever"></span>
                            Abierta
                          </label>
                        </div>
                      </div>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>