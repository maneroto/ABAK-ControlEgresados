    <footer class="page-footer">

      <div class="footer-copyright">
        <div class="container">
        © 2019 A'BAK TEAM - Powered by Tecnológico de Monterrey
        </div>
      </div>
    </footer>
    <?php echo $js;?>

  </body>
</html>