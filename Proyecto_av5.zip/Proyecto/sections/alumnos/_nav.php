        <nav>
            <div class="nav-wrapper">
              <div class="brand-logo">
                  <img src="<?php echo $httpProtocol.$host.$url.'img/inicio/cbtis-logo.png'?>"></img>
              </div>

            </div>
        </nav>
