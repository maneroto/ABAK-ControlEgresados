<?php include '../sections/consultas/_connectDb.php'; ?>
<?php include '../sections/consultas/_headerConsultas.php'; ?>
<?php include '../sections/consultas/_table.php'; ?>
<?php include '../sections/consultas/_footerConsultas.php' ?>