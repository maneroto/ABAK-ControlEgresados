<br /><br />  
           <div class="container">  
                <h3 align="center">Prueba</h3>  
                <br />  
                <div class="table-responsive">  
                     <table id="student_data" class="table table-striped table-bordered">  
                          <thead>  
                               <tr>  
                                    <td>ID</td>  
                                    <td>Nombre</td>  
                                    <td>Apellido Paterno</td>  
                                    <td>Apellido Materno</td>  
                                    <td>Sexo</td>
                                    <td>Email</td>
                                    <td>Teléfono</td>
                                    <td>Especialidad</td>    
                               </tr>  
                          </thead>
                     </table>  
                </div>  
           </div>