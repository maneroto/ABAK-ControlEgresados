	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas.js'?>"></script>
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/jquery-1.12.3.js'?>"></script>
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/bootstrap.min.js'?>"></script>
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/jquery.dataTables.min.js'?>"></script>
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/dataTables.bootstrap.js'?>"></script>
	<!--botones DataTables-->
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/dataTables.buttons.min.js'?>"></script>
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/buttons.bootstrap.min.js'?>"></script>
	<!--Libreria para exportar Excel-->
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/jszip.min.js'?>"></script>
	<!--Librerias para exportar PDF-->
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/pdfmake.min.js'?>"></script>
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/vfs_fonts.js'?>"></script>
	<!--Librerias para botones de exportación-->
	<script src="<?php echo $httpProtocol.$host.$url.'js/consultas_js/buttons.html5.min.js'?>"></script>
	<!--<script src="js/consultas.js"></script>-->
	<!--<script src="js/jquery-1.12.3.js"></script>-->
	<!--<script src="js/bootstrap.min.js"></script>-->
	<!--<script src="js/jquery.dataTables.min.js"></script>-->
	<!--<script src="js/dataTables.bootstrap.js"></script>-->
	<!--botones DataTables-->	
	<!--<script src="js/dataTables.buttons.min.js"></script>-->
	<!--<script src="js/buttons.bootstrap.min.js"></script>-->
	<!--Libreria para exportar Excel-->
	<!--<script src="js/jszip.min.js"></script>-->
	<!--Librerias para exportar PDF-->
	<!--<script src="js/pdfmake.min.js"></script>-->
	<!--<script src="js/vfs_fonts.js"></script>-->
	<!--Librerias para botones de exportación-->
	<!--<script src="js/buttons.html5.min.js"></script>-->
</body>
</html>
