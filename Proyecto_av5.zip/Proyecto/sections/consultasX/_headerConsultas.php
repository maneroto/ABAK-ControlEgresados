<?php
    session_start();
    $httpProtocol = "https://";
    $host = $_SERVER['SERVER_NAME'];
    $url = "/DAW%20REPO/ABAK-ControlEgresados/Proyecto/New%20Interfaces/Proyecto/";
    if(!isset($_SESSION['idrol']) || $_SESSION['idrol']=='ALUMNO')
	{
		header('location: '.$httpProtocol.$host.$url.'index.php');
		exit;
	}
?>
<!DOCTYPE html>
<html lang="es">
<head>
	<meta charset="UTF-8">
	<title>Consultas - CBTis 145</title>
	<link rel="stylesheet" href="<?php echo $httpProtocol.$host.$url.'css/bootstrap.min.css'?>">
	<link rel="stylesheet" href="<?php echo $httpProtocol.$host.$url.'css/dataTables.bootstrap.min.css'?>">
	<link rel="stylesheet" href="<?php echo $httpProtocol.$host.$url.'css/estilos.css'?>">
	<!-- Buttons DataTables -->
    <link rel="stylesheet" href="<?php echo $httpProtocol.$host.$url.'css/buttons.bootstrap.min.css'?>">
	<link rel="stylesheet" href="<?php echo $httpProtocol.$host.$url.'css/font-awesome.min.css'?>">
</head>
<body>